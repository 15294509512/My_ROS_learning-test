
/*客户端person_client的建立--配合person_server服务端的使用，并将请求服务的消息打印出来，同时发送反馈数据*/

#include <ros/ros.h>
#include "test_service/Person.h"

// service回调函数，输入参数req，输出参数res
bool personCallback(test_service::Person::Request  &req,
         			test_service::Person::Response &res)
{
    // 显示请求数据
    ROS_INFO("Person: name:%s  age:%d  sex:%d", req.name.c_str(), req.age, req.sex);

	// 设置反馈数据
	res.result = "OK";

    return true;
}

int main(int argc, char **argv)
{
    // ROS节点初始化
    ros::init(argc, argv, "person_server");

    // 创建节点句柄
    ros::NodeHandle n;

    // 创建一个名为/show_person的server，注册回调函数personCallback
    ros::ServiceServer person_service = n.advertiseService("/show_person", personCallback);

    // 循环等待回调函数
    ROS_INFO("Ready to show person informtion.");
    ros::spin();

    return 0;
}
